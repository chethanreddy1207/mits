# MITS LearnHub 🌐

A medium-level educational platform built with Flask for tutorials, project showcases, certificate verification, and more.

## Features
- ✅ Homepage with featured tutorials
- ✅ Browse tutorials and filter by language/difficulty
- ✅ Project gallery with feedback
- ✅ User login and dashboard
- ✅ Certificate ID verification

## How to Run

```bash
git clone https://github.com/chethanreddyn/mits_learnhub.git
cd mits_learnhub
pip install -r requirements.txt
python app.py
```

Visit `http://127.0.0.1:5000`
