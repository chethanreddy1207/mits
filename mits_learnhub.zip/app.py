from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecret"

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/tutorials')
def tutorials():
    conn = get_db_connection()
    tutorials = conn.execute("SELECT * FROM tutorials").fetchall()
    conn.close()
    return render_template("tutorials.html", tutorials=tutorials)

@app.route('/projects')
def projects():
    conn = get_db_connection()
    projects = conn.execute("SELECT * FROM projects").fetchall()
    conn.close()
    return render_template("projects.html", projects=projects)

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = request.form["username"]
        pwd = request.form["password"]
        if user == "admin" and pwd == "admin":
            session["user"] = user
            return redirect("/dashboard")
        return "Login failed"
    return render_template("login.html")

@app.route('/dashboard')
def dashboard():
    if "user" in session:
        return render_template("dashboard.html", user=session["user"])
    return redirect("/login")

@app.route('/verify', methods=["GET", "POST"])
def verify():
    result = None
    if request.method == "POST":
        cert_id = request.form["cert_id"]
        conn = get_db_connection()
        result = conn.execute("SELECT * FROM certificates WHERE id = ?", (cert_id,)).fetchone()
        conn.close()
    return render_template("verify.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
